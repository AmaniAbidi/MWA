"This repo contains the MEAN stack application that is built in CS572 Modern Web Application course."
