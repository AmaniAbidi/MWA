const gamesData = require("../data/games.json")
const dbConnection = require("../data/dbconnection")

getAll = function(req, res) {
    console.log("Controller getAll invoked");
    let offset = 0
    let count = 5
    console.log(req.query);
    if (req.query && req.query.offset) {
        offset = parseInt(req.query.offset)
    }
    if (req.query && req.query.count) {
        count = parseInt(req.query.count)
    }
    const pageGames = gamesData.slice(offset, offset+count)
    const db = dbConnection.get()
    console.log("db", db);
    res.status(200).json(pageGames)
}

getOne = function(req, res) {
    console.log("Controller getOne invoked");
    const gameId = req.params.gameId
    const theGame = gamesData[gameId]
    res.status(200).json(theGame)
}

addOne = function(req, res) {
    console.log("Controller addOne invoked");
    console.log(req.body);
    res.status(200).json(req.body)
}

module.exports = {
    getAll,
    getOne,
    addOne
}