const dbConnection = require("../data/dbconnection");
const ObjectId = require("mongodb").ObjectId;

getAll = function(req, res) {
    console.log("Controller getAll invoked");
    let offset = 0
    let count = 5
    console.log(req.query);
    if (req.query && req.query.offset) {
        offset = parseInt(req.query.offset)
    }
    if (req.query && req.query.count) {
        count = parseInt(req.query.count)
    }

    const db = dbConnection.get()
    const gamesCollection = db.collection(process.env.DB_GAMES_COLLECTION)
    gamesCollection.find().skip(offset).limit(count).toArray(function(err, games) {
        console.log("Found games");
        res.status(200).json(games)
    })
}

getOne = function(req, res) {
    const gameId = req.params.gameId
    const db = dbConnection.get()
    const gamesCollection = db.collection(process.env.DB_GAMES_COLLECTION)
    gamesCollection.findOne({_id: ObjectId(gameId)}, function(err, game) {
        console.log("Found game");
        res.status(200).json(game)
    })
}

addOne = function(req, res) {
    console.log("Controller addOne invoked");
    console.log(req.body);

    const db = dbConnection.get()
    const gamesCollection = db.collection(process.env.DB_GAMES_COLLECTION)

    if(req.body && req.body.title && req.body.price) {
        console.log("The body is", req.body);
        const newGame = {
            title: req.body.title,
            price: parseFloat(req.body.price)
        }
        gamesCollection.insertOne(newGame, function(err, insertedGame) {
            console.log("InertOne", insertedGame);
            res.status(201).json(insertedGame)
        })
    } else {
        console.log("Data missing from POST body", req.body);
        res.status(400).json({error: "Required data missing from POST"})
    }
}

module.exports = {
    getAll,
    getOne,
    addOne
}